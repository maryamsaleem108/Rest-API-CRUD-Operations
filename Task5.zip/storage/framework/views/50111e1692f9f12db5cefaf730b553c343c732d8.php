<!DOCTYPE html>
<h1>TASK 5</h1>
<h4>Submitted By Maryam Saleem :)</h4>
<?php /**PATH D:\xampp\htdocs\php_practice\Task_5\resources\views/welcome.blade.php ENDPATH**/ ?>